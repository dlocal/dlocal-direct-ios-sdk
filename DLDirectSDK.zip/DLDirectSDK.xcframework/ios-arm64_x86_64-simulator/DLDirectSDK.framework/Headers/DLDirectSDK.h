//
//  DLDirectSDK.h
//  DLDirectSDK
//
//  Created by Nicolas Jakubowski on 1/8/22.
//

#import <Foundation/Foundation.h>

//! Project version number for DLDirectSDK.
FOUNDATION_EXPORT double DLDirectSDKVersionNumber;

//! Project version string for DLDirectSDK.
FOUNDATION_EXPORT const unsigned char DLDirectSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DLDirectSDK/PublicHeader.h>


